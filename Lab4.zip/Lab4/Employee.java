class Employee{
String name;
int yearOfjoining;
String salary;
Employee(String name, int yearOfjoining, String salary){
this.name = name;
this.yearOfjoining = yearOfjoining;
this.salary = salary;
}
public static void main(String [] args){

Employee E1 = new Employee("Robert", 1994, "Wallstreat");
Employee E2 = new Employee("Sam", 2000, "Wallstreat");
Employee E3 = new Employee("john", 1999, "Wallstreat");
System.out.println(E1.name + " " + E1.yearOfjoining + " " + E1.salary);
System.out.println(E2.name + " " + E2.yearOfjoining + " " + E2.salary);
 System.out.println(E3.name + " " + E3.yearOfjoining + " " + E3.salary);
}
}
 
 

