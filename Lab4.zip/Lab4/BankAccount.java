class BankAccount{
// create a variables
     String AccountNumber;
     double balance;
    BankAccount(double balance,String AccountNumber){
    this.balance = balance;
    this.AccountNumber = AccountNumber;
}

  public void displayBalance(){
  System.out.println("balance : " + balance);
  }

public void withdraw(double amount){
      if(amount <= balance){
      balance = balance - amount;
   System.out.println("wothdraw :" + amount);
}
else{
    System.out.println("withdraw is amount is a larger than balance");
}
}

public void deposit (double amount){
        balance = balance + amount;
}

public void checkBalance(){
System.out.println("BankAccount" + AccountNumber + ",balance" + balance);
}

 public static void main(String [] args){

      BankAccount acc1 = new BankAccount(1000.0, "BankAccount:  acc1" );
      BankAccount acc2 = new BankAccount(500.0, "BankAccount: acc2" );
         
  acc1.deposit(500);
  acc2.deposit(1500);
  acc1.checkBalance();
  acc2.checkBalance();
  acc1.withdraw(500);
  acc1.checkBalance();
  acc2.withdraw(3000);

     
}
}



