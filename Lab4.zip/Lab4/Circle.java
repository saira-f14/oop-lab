import java.util.Scanner;
class Circle{
String colour;
double radius;
Circle(String colour, double radius){
this.colour=colour;
this.radius= radius;

}
double calculateArea(){
return 3.14*radius*radius;

}

public static void main(String args[]){
Circle redCircle = new Circle("red",3.14);
Circle greenCircle = new Circle("green",2.14);



System.out.println(greenCircle.colour);
System.out.println(greenCircle.radius);

System.out.println(redCircle.colour);
System.out.println(redCircle.radius);
redCircle.calculateArea();
}
}

