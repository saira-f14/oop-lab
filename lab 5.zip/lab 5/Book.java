class Book{
String title;
String author;
boolean isAvailable;
Book(String title,String author){
this.title = title;
this.author = author;
isAvailable= true;
}
 
public void borrowBook(){
if(isAvailable){
System.out.println("Book is issues: ");
isAvailable= false;
}
else{
System.out.println("Boos is not Available: ");
}

}

void returnBook(){
isAvailable= true;
}


public void displayBookDetails(){
System.out.println(title);
System.out.println(author);
System.out.println(isAvailable);
}


public static void main(String [] args){

Book b1 = new Book("Wren martin: " , "P.C Wren and H.Martin");
b1.borrowBook();
b1.returnBook();
b1.displayBookDetails();
}
}

