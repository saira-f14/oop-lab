class Employee{
String name;
int emplID;
int salary;
Employee(String name, int emplID, int salary){
this.name= name;
this.emplID = emplID;
this.salary= salary;
}

public void increaseSalary(double amount){
salary += amount;
}

public void calculateAnnualSalary(){
System.out.println("The amount of Salary: " + salary*12);
}


public void displayDetails(){
System.out.println(name);
System.out.println(emplID);
System.out.println(salary);
}

public static void main(String [] args){
Employee e1 = new Employee("Saira" , 0014, 7000);
e1.calculateAnnualSalary();
e1.increaseSalary(7000);
e1.displayDetails();
}
}

