public class Main02 {
    public static void main(String[] args) {
        Dog myDog = new Dog("Cat", 23);
        myDog.makeSound();
}
}