class Rectangle extends Shape{
	


void draw(){
	
System.out.println("Drawing a Rectangle");
	
}
}