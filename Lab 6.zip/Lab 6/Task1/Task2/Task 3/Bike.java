class Bike extends Vehicle{
	String helmetTyp;

	Bike( String brand, double speed,String helmetTyp ){
	
	super(brand,speed);
	
	this.helmetTyp=helmetTyp;
}

void showDetails(){
super.showDetails();
System.out.println("HelmetTyp" + helmetTyp);
}
}

