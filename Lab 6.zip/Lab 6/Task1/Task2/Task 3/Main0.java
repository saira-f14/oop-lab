class Main0{
	public static void maian(String [] args){
	Car myCar = new Car("civic" , 60 , 4);
	Bike myBike = new Bike("civic" , 70 , "asia");
    
    

	}
}