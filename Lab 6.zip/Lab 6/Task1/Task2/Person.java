class Person{
	String name;
	int age;


	Person(String name , int age){
	this.name = name;
	this.age = age;


	}

	void displayInfo(){

	System.out.println("The Person name" + name);
	System.out.println("The Person age" + age);

	}
}