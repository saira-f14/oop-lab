class Main01{
	public static void main(String[] arsg){

	GraduateStudent S1 = new GraduateStudent("Saira" , 22, 16, "forces");
	S1.displayInfo();
    


	}



}
