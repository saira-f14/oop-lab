class Main22{
	public static void main(String[] args){
	Calculator calc = new Calculator();
	System.out.println(calc.add(5, 3));


     System.out.println(calc.add(2.5, 3.7));

     System.out.println(calc.add("Hello" , "World"));
}
}