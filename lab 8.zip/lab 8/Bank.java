class Bank{
	double getInterestRate(){
		return 0.0;
	}
}