class Main4{
public static void main(String [] args){
	

	Temperature temp = new Temperature();
 temp.setCelsius(25);  
System.out.println("Fahrenheit: " + temp.getFahrenheit());  
}
}