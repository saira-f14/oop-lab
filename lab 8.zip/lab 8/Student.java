class Student{
	private String name;
	private int rollNumber;
    private String grade;
  

   public void setName(String n) {
    name = n;
}

public String getName() {
    return name;
}

public void setRollNumber(int r) {
    rollNumber = r;
}

public int getRollNumber() {
    return rollNumber;
}

public void setGrade(String g) {
    grade = g;
}

public String getGrade() {
    return grade;
}
  void displayDetails(){
     System.out.println("Name: " + name);
     System.out.println("rollNumber: " + rollNumber);
     System.out.println("Grade: " + grade);



    }
}