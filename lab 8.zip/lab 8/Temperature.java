class Temperature{
	private double celsius;

	public void setCelsius(double c) {
    celsius = c;
}



public double getFahrenheit() {
    return (celsius * 9/5) + 32;
}

}