class Employee{
	
	int calculateBonus(int salary){
      return salary * 10 / 100; 

	}

	int calculateBonus(int salary, int extraHours){
	 return (salary * 10 / 100) + (extraHours * 500);
	 
	}
}