import java.util.Scanner;
public class Task7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
       int[] arr = {6,10,5,3,2,7};
       int largest = arr[0];
       int smallest = arr[0];
for(int i = 0; i<arr.length; i++){
if(arr[i] <smallest){
smallest = arr[i];
}
if(arr[i] < largest){
largest = arr[i];
}
}
System.out.println("Samllest Number" + smallest);
System.out.println("largest Number" + largest);
if(largest%2==0){
System.out.println("This largest number" + largest + "multiple of 2 ");
}
else{
System.out.println("This largest number" + largest + " not multiple of 2");}
}
}

