import java.util.Scanner;
public class Task6 {
    public static void main(String[] args){
Scanner scanner = new Scanner (System.in);
System.out.println("Enter the age: ");
int num = scanner.nextInt();
System.out.println((num <= 18)? "Yes Eligible for voting " : "Not Eligible for voting ");
}
}

       