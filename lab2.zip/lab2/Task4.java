import java.util.Scanner;
public class Task4{
public static void main(String [] args){
Scanner scanner = new Scanner(System.in);
String[] student {"Saira","Muneeba","Saiba","Muqadas","Zara","Fahmida"};
String student1 = sacnner.nextline();
if(student1=="Saira"||student1=="Saira"){
System.out,println("Yes Saira is present");
}
else{
System.out.println("No saira is not  present");

}
}
}

