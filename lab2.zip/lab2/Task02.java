import java.util.Scanner;
public class Task02{
public static void main(String [] args){
Scanner scanner = new Scanner(System.in);
int[] intiger = new int[10];
int sum = 0;
for(int i = 0 ; i < 10; i++){
 System.out.println("Enter the integers");
intiger[i] = scanner.nextInt();
}
for(int i=0;i<10;i++){
System.out.println(" " + intiger[i]);
if(intiger[i]%4==0){
sum += intiger[i];
}
}

System.out.print(sum);


}
}