/* @author Saira */
package Task1;

public class Main {
    public static void main(String[] args){
    Animal myDog = new Dog();
    Animal myCat = new Cat();
    
        System.out.println("\nDog Abstract Class Methods: \n");
        myDog.eat();
        myDog.makeSound();
        
        System.out.println("\nCat Abstract Class Methods: \n");
        myCat.eat();
        myCat.makeSound();
       
    
    
    }
    
}
