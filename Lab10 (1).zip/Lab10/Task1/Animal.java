
/* @author Saira */
package Task1;

public abstract class Animal {
    
    public abstract void makeSound();
    
    public void eat(){
        System.out.println("Animal Eating...");
    }
    
}
