/* @author Saira */
package Task1;

public class Cat extends Animal {
     public void makeSound(){
        System.out.println("Dog Barks...");
    }
    
    public void eat(){
        System.out.println("Dog eats...");
    }
}
