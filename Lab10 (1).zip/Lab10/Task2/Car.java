/* @author Saira */
package Task2;

public class Car implements Vehicle {
    
    public void start(){
         System.out.println("Car starts...");
    }
    
    public void stop(){
         System.out.println("Car stops...");
    }
    
}
