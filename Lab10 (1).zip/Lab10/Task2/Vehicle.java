/* @author Saira */
package Task2;

public interface Vehicle {
    
    public void start();
    
    public void stop();
    
    
    
}
