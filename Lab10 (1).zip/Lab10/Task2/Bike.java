/* @author Saira */
package Task2;

public class Bike implements Vehicle {
    
    public void start(){
         System.out.println("Bike starts...");
    }
    
    public void stop(){
         System.out.println("Bike stops...");
    }
    
}
