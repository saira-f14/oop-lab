
/* @author Saira */
package Task5;


public interface TaxPayer {
    
    public void payTax();
    
}
