/* @author Saira */
package Task5;

class PartTimeEmployee extends Employee implements TaxPayer {
    private int hoursWorked;
    private double hourlyRate;

    public PartTimeEmployee(String name, int id, int hoursWorked, double hourlyRate) {
        super(name, id);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }
 
    public double calculateSalary() {
        return hoursWorked * hourlyRate;
    }

    public void payTax() {
        double salary = calculateSalary();
        double tax = salary * 0.1;
        System.out.println("Part-time Employee " + name + " pays tax: $" + tax);
    }
}
