
/* @author Saira */
package Task4;

public class Duck implements Flyable,Swimmable {
    
    public void fly(){
        System.out.println("Duck flies...");
    }
    
    public void swim(){
        System.out.println("Duck swims...");
    }
    
}
