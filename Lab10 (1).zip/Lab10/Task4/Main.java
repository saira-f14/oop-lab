
/* @author Saira */
package Task4;

public class Main {
    public static void main(String[] args){
    Flyable d1 = new Duck();
    Swimmable d2 = new Duck();
    
        System.out.println("Duck Properties: ");
        d1.fly();
        d2.swim();
        
    }
}
