
/* @author Saira */
package Task4;

public interface Flyable {
    public void fly();
}
