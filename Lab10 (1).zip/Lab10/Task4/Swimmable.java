
/* @author Saira */
package Task4;


public interface Swimmable {
    
    public void swim();
    
}
