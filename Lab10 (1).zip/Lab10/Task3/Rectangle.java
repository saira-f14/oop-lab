/* @author Saira */
package Task3;

public class Rectangle extends Shape implements Printable {
    
    public void area(double pie, double radius){
        System.out.println("Total Rectangle Area..." + (pie * radius * radius));
    }
    
    public void print(){
        System.out.println("Rectangle prints...");
    }
}
