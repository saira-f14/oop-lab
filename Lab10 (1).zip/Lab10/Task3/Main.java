
/* @author Saira */
package Task3;

public class Main {
    public static void main(String[] args){
        Shape r1 = new Rectangle();
        Printable  r2 = new Rectangle();
        
        System.out.println("\nRectangle Area: \n");
        r1.area(3.14, 4);
        
        System.out.println("\nRectangle Printable: \n");
        r2.print();
    
        
    
    
    }
    
}
