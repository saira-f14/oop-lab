/* @author Saira */
package Task3;

public abstract class Shape {
    
    public abstract void area(double pie, double radius);
    
}
