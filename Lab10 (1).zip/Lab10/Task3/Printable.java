/* @author Saira */
package Task3;

public interface Printable {
    
    public void print();
    
}
